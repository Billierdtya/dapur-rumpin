<?php
// ============================================================
//  logout.php  (taruh di root project)
// ============================================================

session_start();

// Hapus semua data session
$_SESSION = [];

// Hapus cookie session dari browser juga
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Destroy session di server
session_destroy();

// Redirect ke login dengan pesan sukses
header('Location: login.php?err=logged_out');
exit;